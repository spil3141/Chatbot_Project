function response(room, msg, sender, isGroupChat, replier){
	//replier.reply(" spil3141, is awesome 🤣.");
  if(sender == "francine"){
    replier.reply("Yes");
  }
}
